@extends('user.layouts.app')
@section('title')
    @lang('Service')
@endsection
@section('content')

    <div class="contain-cards-order">
        <h3>Add Order</h3>
        <div class="search">
            <input type="text">
            <button class="btn">search</button>
        </div>
        <div class="cards-order">
            @foreach($categories as $category)
            <a href="{{route('user.services.show',$category->id)}}">
                <div class="item">
                    <img src="{{ getFile(config('location.category.path').$category->image) }}" alt="user">
                    <div class="name">{{$category->category_title }}</div>
                </div>
            </a>
            @endforeach
        </div>
    </div>
@endsection
@push('js')
    <script>
        "use strict";
        $('#cards-services .item').on('click', function (event) {
            if($(this).hasClass("disable")){
                event.preventDefault();
            }
           else if($(this).hasClass("active")){
                $(this).removeClass('active');
                $('#cards-services .item').removeClass('un-active');
            }
            else{
                $('#cards-services .item').removeClass('active');
                $('#cards-services .item').addClass('un-active');
                $(this).addClass('active');
            }
            
            event.preventDefault();
        });
    </script>
@endpush

